<?php
 return array (
  '_id' => 'orders5c58037634d2f',
  'name' => 'orders',
  'label' => 'oders form',
  'save_entry' => true,
  'in_menu' => false,
  'email_forward' => 'juliusmubajje1@gmail.com',
  '_created' => 1549271926,
  '_modified' => 1549271926,
  'color' => '#FFCE54',
);