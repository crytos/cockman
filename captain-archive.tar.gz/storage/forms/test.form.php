<?php
 return array (
  '_id' => 'test5c6856408121f',
  'name' => 'test',
  'label' => 'test',
  'save_entry' => true,
  'in_menu' => false,
  'email_forward' => 'juliusmubajje1@gmail.com',
  '_created' => 1550341696,
  '_modified' => 1550341696,
  'description' => 'test',
);